let word = document.getElementById('word');
let text = document.getElementById('text');
let scoreEl = document.getElementById('score');
let timeEl = document.getElementById('time');
let endgameEl = document.getElementById('end-game-container');

words = [
    'finish',
    'glance',
    'broadcast',
    'conceive',
    'exaggerate',
    'astonishing',
    'speculate',
    'behavior',
    'progress',
    'inject',
    'acquisition',
    'advertising',
    'dangerous',
    'education',
    'face',
    'spend',
    'simplicity',
    'bean',
    'exploit',
    'unit'
]
let randomWord = '';
let score = 0;
let time = 10;

let timeInterval = setInterval(updateTime, 1000);

function gameOver() {
    endgameEl.innerHTML = `<h1>Time is up!</h1>
                            <p>Your final result is ${score}
                            <button onclick = "location.reload()">Try Again</button>

    `;

    endgameEl.style.display = 'flex';
}

function getRandomWords() {
    randomNumber = Math.floor(Math.random() * words.length);
    return words[randomNumber];
}

function placeRandomWord() {
    randomWord = getRandomWords();
    word.innerText = randomWord;
}

function updateTime() {
    time--

    timeEl.innerText = time + 's'
    if(time == 0) {
        clearInterval(timeInterval);
        gameOver();
    }
}
function updateScore() {
    score++
    scoreEl.innerText = score
}

placeRandomWord();

text.addEventListener('input', e => {
    insertedText = e.target.value;

    if(insertedText == randomWord) {
        placeRandomWord()
        updateScore();

        text.value = '';

        time += 3;
        updateTime();
    }
})